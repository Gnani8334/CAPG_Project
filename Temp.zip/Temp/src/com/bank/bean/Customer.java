package com.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer_db")
public class Customer
{
	private String name;
	private String emailId;
	private StringBuffer address;
	private String mobileno;
	private String panno;
	private	int age;
	@Id
	private int accNumber;
	private	int pin;
	private double currBal=0.0;
	public Customer()
	{

	}
public Customer(String name, String emailId, 
			StringBuffer address, String mobileno, String panno, int age,
			int accNumber, int pin, double currBal) {
		super();
		this.name = name;
		this.emailId = emailId;
		
		this.address = address;
		this.mobileno = mobileno;
		this.panno = panno;
		this.age = age;
		this.accNumber = accNumber;
		this.pin = pin;
		this.currBal = currBal;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}




	public StringBuffer getAddress() {
		return address;
	}


	public void setAddress(StringBuffer address) {
		this.address = address;
	}


	public String getMobileno() {
		return mobileno;
	}


	public int getAccNumber() {
		return accNumber;
	}


	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}


	public int getPin() {
		return pin;
	}


	public void setPin(int pin) {
		this.pin = pin;
	}


	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	public String getPanno() {
		return panno;
	}


	public void setPanno(String panno) {
		this.panno = panno;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public double getCurrBal() {
		return currBal;
	}


	public void setCurrBal(double currBal) {
		this.currBal = currBal;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", emailId=" + emailId + ", address="
				+ address + ", mobileno=" + mobileno + ", panno=" + panno
				+ ", age=" + age + ", accNumber=" + accNumber + ", pin=" + pin
				+ ", currBal=" + currBal + "]";
	}


	


}

