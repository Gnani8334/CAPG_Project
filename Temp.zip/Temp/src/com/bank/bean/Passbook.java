package com.bank.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passbook_db")
public class Passbook {
	@Id
	int accNumber;
	String Details;
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public String getDetails() {
		return Details;
	}
	public void setDetails(String details) {
		Details = details;
	}
	@Override
	public String toString() {
		return "Passbook [accNumber=" + accNumber + ", Details=" + Details
				+ "]";
	}
	

}
